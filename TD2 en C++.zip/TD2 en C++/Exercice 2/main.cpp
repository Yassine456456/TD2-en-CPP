
#include <iostream>
#include "MatrixBase.h"
#include "MatrixNumerical.h"

int main() {
    try {
        // Creation de deux matrices
        MatrixNumerical<double> A({
            {1, 2},
            {3, 4}
        });

        MatrixNumerical<double> B({
            {5, 6},
            {7, 8}
        });

        std::cout << "=== Matrice A ===\n";
        A.Display();

        std::cout << "\n=== Matrice B ===\n";
        B.Display();

        std::cout << "\n=== A + B ===\n";
        (A + B).Display();

        std::cout << "\n=== A - B ===\n";
        (A - B).Display();

        std::cout << "\n=== A * B ===\n";
        (A * B).Display();

        std::cout << "\n=== Determinant de A ===\n";
        std::cout << A.getDeterminant() << '\n';

        std::cout << "\n=== Inverse de A ===\n";
        A.getInverse().Display();

        std::cout << "\n=== A / B ===\n";
        (A / B).Display();

        std::cout << "\n=== Matrice identite 3x3 ===\n";
        MatrixNumerical<double>::getIdentity(3).Display();

        std::cout << "\n=== Test getElement ===\n";
        std::cout << "A[0][1] = "
                  << A.getElement(0, 1) << '\n';

        std::cout << "\nNombre de lignes : "
                  << A.getRows() << '\n';

        std::cout << "Nombre de colonnes : "
                  << A.getCols() << '\n';
    }
    catch (const std::exception& e) {
        std::cerr << "Erreur : " << e.what() << '\n';
        return 1;
    }

    return 0;
}
