
#ifndef MATRIXBASE_H
#define MATRIXBASE_H

#include <iostream>
#include <vector>
#include <stdexcept>

template <typename T>
class MatrixBase {
protected:
    std::vector<std::vector<T>> data;
    size_t rows;
    size_t cols;

public:
    // Constructeur par defaut
    MatrixBase() : rows(0), cols(0) {}

    // Constructeur avec nombre de lignes et de colonnes
    MatrixBase(size_t r, size_t c)
        : data(r, std::vector<T>(c, T{})), rows(r), cols(c) {}

    // Constructeur a partir d'un tableau 2D
    MatrixBase(const std::vector<std::vector<T>>& values)
        : data(values),
          rows(values.size()),
          cols(values.empty() ? 0 : values[0].size()) {
        for (const auto& line : values) {
            if (line.size() != cols) {
                throw std::invalid_argument(
                    "Toutes les lignes doivent avoir la meme taille.");
            }
        }
    }

    // Ajouter ou modifier un element
    void addElement(size_t row, size_t col, T value) {
        if (row >= rows || col >= cols) {
            throw std::out_of_range("Indice hors limites.");
        }

        data[row][col] = value;
    }

    // Recuperer un element
    T getElement(size_t row, size_t col) const {
        if (row >= rows || col >= cols) {
            throw std::out_of_range("Indice hors limites.");
        }

        return data[row][col];
    }

    // Nombre de lignes
    size_t getRows() const {
        return rows;
    }

    // Nombre de colonnes
    size_t getCols() const {
        return cols;
    }

    // Afficher la matrice
    void Display() const {
        for (size_t i = 0; i < rows; i++) {
            for (size_t j = 0; j < cols; j++) {
                std::cout << data[i][j] << "\t";
            }
            std::cout << '\n';
        }
    }
};

#endif
