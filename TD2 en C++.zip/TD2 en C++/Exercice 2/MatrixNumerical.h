
#ifndef MATRIXNUMERICAL_H
#define MATRIXNUMERICAL_H

#include "MatrixBase.h"
#include <cmath>
#include <algorithm>

// Declaration anticipee
template <typename T>
class MatrixNumerical;

template <typename T>
MatrixNumerical<T> getCoFactor(
    const MatrixNumerical<T>& matrix,
    size_t excludedRow,
    size_t excludedCol);

template <typename T>
class MatrixNumerical : public MatrixBase<T> {
    using Base = MatrixBase<T>;

public:
    // Constructeurs
    MatrixNumerical() : Base() {}

    MatrixNumerical(size_t r, size_t c) : Base(r, c) {}

    MatrixNumerical(const std::vector<std::vector<T>>& values)
        : Base(values) {}

    // Determinant
    T getDeterminant() const {
        if (this->rows != this->cols) {
            throw std::invalid_argument(
                "Le determinant exige une matrice carree.");
        }

        size_t n = this->rows;

        if (n == 0) return T{1};
        if (n == 1) return this->data[0][0];

        if (n == 2) {
            return this->data[0][0] * this->data[1][1]
                 - this->data[0][1] * this->data[1][0];
        }

        T determinant = T{};

        for (size_t j = 0; j < n; j++) {
            auto minor = getCoFactor(*this, 0, j);

            T sign = (j % 2 == 0) ? T{1} : T{-1};

            determinant += sign * this->data[0][j]
                         * minor.getDeterminant();
        }

        return determinant;
    }

    // Addition de matrices
    MatrixNumerical operator+(const MatrixNumerical& other) const {
        if (this->rows != other.rows ||
            this->cols != other.cols) {
            throw std::invalid_argument(
                "Dimensions incompatibles pour l'addition.");
        }

        MatrixNumerical result(this->rows, this->cols);

        for (size_t i = 0; i < this->rows; i++) {
            for (size_t j = 0; j < this->cols; j++) {
                result.data[i][j] =
                    this->data[i][j] + other.data[i][j];
            }
        }

        return result;
    }

    // Soustraction de matrices
    MatrixNumerical operator-(const MatrixNumerical& other) const {
        if (this->rows != other.rows ||
            this->cols != other.cols) {
            throw std::invalid_argument(
                "Dimensions incompatibles pour la soustraction.");
        }

        MatrixNumerical result(this->rows, this->cols);

        for (size_t i = 0; i < this->rows; i++) {
            for (size_t j = 0; j < this->cols; j++) {
                result.data[i][j] =
                    this->data[i][j] - other.data[i][j];
            }
        }

        return result;
    }

    // Multiplication matricielle
    MatrixNumerical operator*(const MatrixNumerical& other) const {
        if (this->cols != other.rows) {
            throw std::invalid_argument(
                "Dimensions incompatibles pour la multiplication.");
        }

        MatrixNumerical result(this->rows, other.cols);

        for (size_t i = 0; i < this->rows; i++) {
            for (size_t j = 0; j < other.cols; j++) {
                for (size_t k = 0; k < this->cols; k++) {
                    result.data[i][j] +=
                        this->data[i][k] * other.data[k][j];
                }
            }
        }

        return result;
    }

    // Matrice inverse
    MatrixNumerical getInverse() const {
        if (this->rows != this->cols) {
            throw std::invalid_argument(
                "L'inverse exige une matrice carree.");
        }

        size_t n = this->rows;
        T determinant = getDeterminant();

        if (std::abs(static_cast<double>(determinant)) < 1e-12) {
            throw std::invalid_argument(
                "Cette matrice n'est pas inversible.");
        }

        MatrixNumerical inverse(n, n);

        for (size_t i = 0; i < n; i++) {
            for (size_t j = 0; j < n; j++) {
                auto minor = getCoFactor(*this, j, i);

                T sign = ((i + j) % 2 == 0) ? T{1} : T{-1};

                inverse.data[i][j] =
                    sign * minor.getDeterminant() / determinant;
            }
        }

        return inverse;
    }

    // Division matricielle : A / B = A * inverse(B)
    MatrixNumerical operator/(const MatrixNumerical& other) const {
        return *this * other.getInverse();
    }

    // Matrice identite
    static MatrixNumerical getIdentity(int n) {
        if (n < 0) {
            throw std::invalid_argument("Taille negative.");
        }

        MatrixNumerical identity(n, n);

        for (int i = 0; i < n; i++) {
            identity.data[i][i] = T{1};
        }

        return identity;
    }
};

// Fonction hors de la classe : construit le mineur
template <typename T>
MatrixNumerical<T> getCoFactor(
    const MatrixNumerical<T>& matrix,
    size_t excludedRow,
    size_t excludedCol) {

    if (matrix.getRows() != matrix.getCols() ||
        excludedRow >= matrix.getRows() ||
        excludedCol >= matrix.getCols()) {
        throw std::invalid_argument("Mineur invalide.");
    }

    size_t n = matrix.getRows();
    MatrixNumerical<T> minor(n - 1, n - 1);

    size_t r = 0;

    for (size_t i = 0; i < n; i++) {
        if (i == excludedRow) continue;

        size_t c = 0;

        for (size_t j = 0; j < n; j++) {
            if (j == excludedCol) continue;

            minor.addElement(
                r, c, matrix.getElement(i, j));

            c++;
        }

        r++;
    }

    return minor;
}

#endif
